import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.* ;
import java.util.*;

public class ChangePin extends JFrame implements ActionListener{
	static String pin;
	static String formno;
	JLabel l1,l2,l4;
	JButton b1,b2,b3;
	JPasswordField t1,t2;
	public ChangePin(String formno, String pin) {
		setTitle("WELCOME"); //set title of window
		setLayout(null); 
		ChangePin.pin = pin;
		ChangePin.formno = formno;
		setSize(1600,900);	//defines size of frame
		getContentPane().setBackground(Color.WHITE);
		setLocation(0,0); //set location of window with reference to the top left corner as origin
		 
		String imagePath = "icons/atm.jpg";
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource(imagePath));
		Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
	    ImageIcon i3 = new ImageIcon(i2);
	    JLabel l3 = new JLabel(i3);
	    l3.setBounds(0, 0, 960, 1080);
	    add(l3);
	    
	    l1 = new JLabel("CHANGE YOUR PIN");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 16));
        l1.setBounds(265,400,700,35);
        l3.add(l1);
        
        l2 = new JLabel("Enter new PIN: ");
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("System", Font.BOLD, 16));
        l2.setBounds(185,480,150,35);
        l3.add(l2);
        l4 = new JLabel("Re-enter new PIN: ");
        l4.setForeground(Color.WHITE);
        l4.setFont(new Font("System", Font.BOLD, 16));
        l4.setBounds(185,535,175,35);
        l3.add(l4);
        
        t1 = new JPasswordField();
        t1.setFont(new Font("Raleway", Font.BOLD, 22));
        t1.setBounds(380,485,130,25);
        l3.add(t1);
        t2 = new JPasswordField();
        t2.setFont(new Font("Raleway", Font.BOLD, 22));
        t2.setBounds(380,540,130,25);
        l3.add(t2);
        
        b1 = new JButton("SAVE");
        b1.setBounds(180,600,90,35);
        b1.addActionListener(this);        
        l3.add(b1);
        b2 = new JButton("CLEAR");
        b2.setBounds(310,600,90,35);
        b2.addActionListener(this);        
        l3.add(b2);
        b3 = new JButton("EXIT");
        b3.setBounds(440,600,90,35);
        b3.addActionListener(this);        
        l3.add(b3);
        
        
        setSize(960,1080);
        setUndecorated(true);
        setLocation(500,0);
	    setVisible(true);
	}

	public static void main(String[] args) {
		new ChangePin(formno,pin);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String npin = t1.getText();
		String rpin = t2.getText();
		if(e.getSource()==b1) {
			if(npin.equals("") || rpin.equals("")) {
				JOptionPane.showMessageDialog(null,"Please fill both PIN fields");
				t1.setText("");
				t2.setText("");
			}
			else if(npin.equals(rpin)) {
				try {
				    DatabaseConnection conn = new DatabaseConnection();
//				    String query1 = "update bank set pin = '" + rpin + "' where formno = '" + formno + "'";
				    String query2 = "update login set pin = '" + rpin + "' where formno = '" + formno + "'";
				    String query3 = "update signupadditionaltable set pin = '" + rpin + "' where formno = '" + formno + "'";
				    
//				    int rowsAffected1 = conn.s.executeUpdate(query1);
				    int rowsAffected2 = conn.s.executeUpdate(query2);
				    int rowsAffected3 = conn.s.executeUpdate(query3);
				    
				    if (rowsAffected2 > 0 && rowsAffected3 > 0) {
				        JOptionPane.showMessageDialog(null, "PIN Changed successfully!");
				        new Transactions(formno,rpin);
				        setVisible(false);
				    }else {
				        // Handle the case when the update didn't affect any rows
				        JOptionPane.showMessageDialog(null, "Failed to change PIN. No records updated.");
				    }
				}
					catch (SQLException e1) {
				    System.out.println(e1);
				}
			}else {
				JOptionPane.showMessageDialog(null,"Re-entered password doesn't match first!");
			}
		}else if(e.getSource()==b2) {
			t1.setText("");
			t2.setText("");
		}else if(e.getSource()==b3) {
			new Transactions(formno,pin);
			setVisible(false);
		}
	}

}
