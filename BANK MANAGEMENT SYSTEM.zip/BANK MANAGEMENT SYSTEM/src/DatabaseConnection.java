import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {

    Connection c;
    Statement s;

    public DatabaseConnection() {
        try {
            c = DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem", "root", "654645");
            s = c.createStatement();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    // Other methods for database operations using 'c' and 's'...

}
