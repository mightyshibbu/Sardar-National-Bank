import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;

import javax.swing.* ;
import java.util.*;

public class Deposit extends JFrame implements ActionListener{
	JTextField t1,t2;
    JButton b1,b2,b3;
    JLabel l1,l2,l3;
    static String pin,formno;
	Deposit(String formno, String pin)
	{
		setTitle("WELCOME"); //set title of window
		setLayout(null); 
		this.pin = pin;
		setSize(1600,900);	//defines size of frame
		getContentPane().setBackground(Color.WHITE);
		setLocation(0,0); //set location of window with reference to the top left corner as origin
		 
		String imagePath = "icons/atm.jpg";
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource(imagePath));
		Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
	    ImageIcon i3 = new ImageIcon(i2);
	    JLabel l3 = new JLabel(i3);
	    l3.setBounds(0, 0, 960, 1080);
	    add(l3);
	    
	    l1 = new JLabel("ENTER AMOUNT YOU WANT TO DEPOSIT");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 16));
        
        t1 = new JTextField();
        t1.setFont(new Font("Raleway", Font.BOLD, 22));
        
        b1 = new JButton("DEPOSIT");
        b2 = new JButton("BACK");
        
        setLayout(null);
        
        l1.setBounds(190,350,400,35);
        l3.add(l1);
        
        t1.setBounds(190,420,320,25);
        l3.add(t1);
        
        b1.setBounds(390,588,150,35);
        l3.add(b1);
        
        b2.setBounds(390,633,150,35);
        l3.add(b2);
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        
        setSize(960,1080);
        setUndecorated(true);
        setLocation(500,0);
		setVisible(true);
	}
	public static void main(String[] args) {
		new Deposit(formno,pin);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b1) {
			String amount = t1.getText();
			Date date = new Date();
			if(amount.equals("")) {
				JOptionPane.showMessageDialog(null,"Please enter an amount");
			}else {
				try {
					DatabaseConnection conn = new DatabaseConnection();
					String query = "insert into bank values('"+formno+"','"+pin+"','"+date+"','Deposit','"+amount+"')";
					conn.s.executeUpdate(query);
					JOptionPane.showMessageDialog(null,"Amount "+amount+" succesfully deposited!");
					new Transactions(formno,pin);
					setVisible(false);
					
				}catch (SQLException e1) {
					e1.printStackTrace();
					System.out.println(e1);
				}
				
			}
		}else if(e.getSource()==b2) {
			new Transactions(formno,pin);
			setVisible(false);
		}
	}

}
