import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import javax.swing.* ;
import java.util.*;

public class FastCash extends JFrame implements ActionListener{

	static String pin;
	static String formno;
	JLabel l1;
    JButton b1,b2,b3,b4,b5,b6,b7;
	public FastCash(String formno, String pin) {
		setTitle("WELCOME"); //set title of window
		setLayout(null); 
		this.pin = pin;
		this.formno = formno;
		setSize(1600,900);	//defines size of frame
		getContentPane().setBackground(Color.WHITE);
		setLocation(0,0); //set location of window with reference to the top left corner as origin
		 
		String imagePath = "icons/atm.jpg";
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource(imagePath));
		Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
	    ImageIcon i3 = new ImageIcon(i2);
	    JLabel l3 = new JLabel(i3);
	    l3.setBounds(0, 0, 960, 1080);
	    add(l3);
	    
	    l1 = new JLabel("SELECT WITHDRAWL AMOUNT");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 16));
        
        b1 = new JButton("500");
        b2 = new JButton("1000");
        b3 = new JButton("1500");
        b4 = new JButton("2000");
        b5 = new JButton("5000");
        b6 = new JButton("10000");
        b7 = new JButton("EXIT");
        
        setLayout(null);
        
        l1.setBounds(235,400,700,35);
        l3.add(l1);
        
        b1.setBounds(170,499,150,35);
        l3.add(b1);
        
        b2.setBounds(390,499,150,35);
        l3.add(b2);
        
        b3.setBounds(170,543,150,35);
        l3.add(b3);
        
        b4.setBounds(390,543,150,35);
        l3.add(b4);
        
        b5.setBounds(170,588,150,35);
        l3.add(b5);
        
        b6.setBounds(390,588,150,35);
        l3.add(b6);
        
        b7.setBounds(390,633,150,35);
        l3.add(b7);
        
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);
	    
	    setSize(960,1080);
        setUndecorated(true);
        setLocation(500,0);
	    setVisible(true);
	}

	public static void main(String[] args) {
		new FastCash(formno,pin);
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		String amount="";
		if(ae.getSource()==b1){ 
			amount = "500";
		}else if(ae.getSource()==b2){ 
			 amount = "1000";
		}else if(ae.getSource()==b3){ 
			amount = "1500";
		
		}else if(ae.getSource()==b4){ 
			amount = "2000";
		
		}else if(ae.getSource()==b5){ 
			amount = "5000";
		}
		else if(ae.getSource()==b6){ 
			amount = "10000";
		}
		else if(ae.getSource()==b7){ 
			setVisible(false);
            System.exit(0);
		}
		Date date = new Date();
		try {
			DatabaseConnection conn = new DatabaseConnection();
			String query = "insert into bank values('"+formno+"','"+pin+"','"+date+"','Withdraw','"+amount+"')";
			conn.s.executeUpdate(query);
			JOptionPane.showMessageDialog(null,"Amount "+amount+" debited succesfully!");
			new Transactions(formno,pin);
			setVisible(false);
				
		}catch(SQLException e1) {
			e1.printStackTrace();
			System.out.println(e1);
		}
	        
		
	}

}
