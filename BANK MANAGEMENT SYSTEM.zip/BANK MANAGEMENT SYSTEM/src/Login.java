import javax.swing.*; 												//1. Import swing to use Frames
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
public class Login extends JFrame implements ActionListener { 					//2. extend your class using inheritance
 
	
	private static final long serialVersionUID = 1L;
	JButton Clear_up_button, sign_up_button,sign_in_button; //Global Variable
	JTextField card_textfield;																	//Global Variable 
	JPasswordField pin_textfield;															//Global Variable
	
	Login(){																			//4.  Define your constructor, it will be called when an object will be created. 
	 
	 setVisible(true); 		//makes the frame visible to user, it is FALSE by default
	 setSize(1600,900);	//defines size of frame
	 getContentPane().setBackground(Color.WHITE);
	 setLayout(null); 
	 setLocation(0,0); //set location of window with reference to the top left corner as origin
	 
	 setTitle("AUTOMATED TELLER MACHINE"); //set title of window
	 
	 ImageIcon logo = new ImageIcon(ClassLoader.getSystemResource("/icons/logo.jpg")); 			//introduce (image) logo's address.		
	 Image logo_but_scaled =  logo.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT); //use image class to scale that imageicon
	 ImageIcon valid_icon = new ImageIcon(logo_but_scaled); //again convert it to ImageIcon type , now your image is ready to get added on the frame
	 JLabel icon = new JLabel(valid_icon);   
	 icon.setBounds(420,10 , 100, 110);
	 add(icon); //show it on frame or window wtvr
	 
	 JLabel sardar_national_bank = new JLabel("SARDAR NATIONAL BANK");
	 sardar_national_bank.setFont(new Font("Osward", Font.BOLD, 38));
	 sardar_national_bank.setBounds(550, 40, 1000,40);
	 add(sardar_national_bank);
	 
	 JLabel card_number = new JLabel("Card Number:");
	 card_number .setBounds(500, 180, 1000,40);
	 card_number .setFont(new Font("Raleway", Font.PLAIN, 32));
	 add(card_number);
	 
	 card_textfield = new JTextField();
	 card_textfield.setBounds(750, 180 , 400,40 );
	 add(card_textfield);
	 
	 JLabel pin_number = new JLabel("Enter PIN:");
	 pin_number .setBounds(500, 270, 1000,40);
	 pin_number .setFont(new Font("Raleway", Font.PLAIN, 32));
	 add(pin_number);
	 
	  pin_textfield = new JPasswordField();
	 pin_textfield.setBounds(750, 270 , 400,40 );
	 add(pin_textfield);
	 
	  
	 sign_in_button = new JButton("SIGN IN");
	 sign_in_button.setBounds(650, 350, 100,40);
	 sign_in_button.setBackground(Color.BLACK);
	 sign_in_button.setForeground(Color.WHITE);
	 sign_in_button.addActionListener(this);
	 add(sign_in_button);
	 
	 Clear_up_button = new JButton("CLEAR");
	 Clear_up_button.setBounds(780, 350, 100,40);
	 Clear_up_button.setBackground(Color.BLACK);
	 Clear_up_button.setForeground(Color.WHITE);
	 Clear_up_button.addActionListener(this);
	 add(Clear_up_button);
	 
	 sign_up_button = new JButton("SIGN UP");
	 sign_up_button.setBounds(650, 400, 230,40);
	 sign_up_button.setBackground(Color.BLACK);
	 sign_up_button.setForeground(Color.WHITE);
	 sign_up_button.addActionListener(this);
	 add(sign_up_button);

 }	
 
 // Making buttons work!
 
 public void actionPerformed(ActionEvent ae) {
	 if(ae.getSource()== Clear_up_button) {
		 card_textfield.setText("");
		 pin_textfield.setText("");
	 }else if(ae.getSource()==sign_up_button)
	 {
		 setVisible(false);
		 new SignupOne();
		 
	 }else if(ae.getSource()==sign_in_button)
	 {
		 DatabaseConnection conn = new DatabaseConnection() ; 
		 String cardnumber = card_textfield.getText();
		 String pin = String.valueOf(pin_textfield.getPassword());
		 String query = "select * from login where cardnumber = '"+cardnumber+"' and pin = '"+pin+"'";
		 try {
			 ResultSet rs = conn.s.executeQuery(query);
			 boolean check = rs.next();
			 if(check) {
				 String formno = rs.getString("formno");
				 setVisible(false);
				 new Transactions(formno,pin).setVisible(true);
			 }else {
				 System.out.println(check);
				 JOptionPane.showMessageDialog(null,"Incorrect card number or pin!");
			 }
		 } catch (Exception e){
			 System.out.println(e);
		 }
	 }
	 
 }
 
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login obj= new Login(); 														// 3.define a new object of class this class 
	}

}
