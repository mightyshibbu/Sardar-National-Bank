import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.*;
import java.util.Iterator;
import java.util.Random;
import com.toedter.calendar.JDateChooser;
import javax.swing.*; 												//1. Import swing to use Frames
import java.awt.*;

public class SignupOne extends JFrame implements ActionListener {
	long random;
	JTextField nametf,fatherstf,dobtf,emailtf,addresstf,statetf,citytf,pincodetf;
	JButton next;
	JRadioButton male,female,others,married,unmarried;
	JDateChooser date;
	String sendformno;
	SignupOne(){
		
		 setVisible(true); 
		 getContentPane().setBackground(Color.WHITE);
		 setSize(1600,900);	//defines size of frame
		 setLocation(0,0); //set location of window with reference to the top left corner as origin
		 setLayout(null); 
		 setTitle("SIGN UP Page 1"); //set title of window
		 
		 Random ran = new Random();
		 long num =Math.abs( ran.nextLong() % 10000 + 1);
		 sendformno = Long.toString(num);
		 JLabel formnumber = new JLabel("APPLICATION FORM NO. " + sendformno );
		 formnumber.setFont(new Font("Raleway",Font.BOLD, 30));
		 formnumber.setBounds(500,40,600,40);
		 add(formnumber);
		 JLabel personalDetails = new JLabel("Page 1: PERSONAL DETAILS ");
		 personalDetails.setFont(new Font("Raleway",Font.BOLD, 24));
		 personalDetails.setBounds(550,100,600,40);
		 add(personalDetails);
		 
		 JLabel name = new JLabel("Name:");
		 name.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 name.setBounds(500,200,150,40);
		 add(name);
		  nametf = new JTextField();
		 nametf.setFont(new Font("Raleway", Font.BOLD,14));
		 nametf.setBounds(680, 200, 300, 40);
		 add(nametf);
		 
		 
		 JLabel fname = new JLabel("Father's Name: ");
		 fname.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 fname.setBounds(500,250,300,40);
		 add(fname);
		  fatherstf = new JTextField();
		 fatherstf.setFont(new Font("Raleway", Font.BOLD,14));
		 fatherstf.setBounds(680, 250, 300, 40);
		 add(fatherstf);
		 
		 JLabel dob = new JLabel("Date of Birth: ");
		 dob.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 dob.setBounds(500,300,300,40);
		 add(dob);
		 date= new JDateChooser();
		 date.setBounds(680, 300, 300, 40);
		 date.setForeground(Color.red);
		 add(date);

		 JLabel gender = new JLabel("Gender: ");
		 gender.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 gender.setBounds(500,350,300,40);
		 add(gender);
		 
		 male = new JRadioButton("Male");
		 male.setBounds(680, 350, 100, 40);
		 male.setFont(new Font("Raleway", Font.BOLD,14));
		 male.setBackground(Color.white);
		 add(male);
		 
		 female = new JRadioButton("Female");
		 female.setFont(new Font("Raleway", Font.BOLD,14));
		 female.setBackground(Color.white);
		 female.setBounds(800, 350, 100, 40);
		 add(female);
		 		 
		 ButtonGroup maleORfemale = new ButtonGroup();
		 maleORfemale.add(male);
		 maleORfemale.add(female);
		 
		 JLabel email = new JLabel("Email: ");
		 email.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 email.setBounds(500,400,300,40);
		 add(email);
		 emailtf = new JTextField();
		 emailtf.setFont(new Font("Raleway", Font.BOLD,14));
		 emailtf.setBounds(680, 400, 300, 40);
		 add(emailtf);
		 
		 JLabel Marital_status = new JLabel("Marital Status: ");
		 Marital_status.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 Marital_status.setBounds(500,450,300,40);
		 add(Marital_status);
		 married = new JRadioButton("Married");
		 married.setBounds(680, 450, 100, 40);
		 married.setFont(new Font("Raleway", Font.BOLD,14));
		 married.setBackground(Color.white);
		 add(married);		 
		 unmarried = new JRadioButton("Unmarried");
		 unmarried.setFont(new Font("Raleway", Font.BOLD,14));
		 unmarried.setBackground(Color.white);
		 unmarried.setBounds(800, 450, 100, 40);
		 add(unmarried);
		 others = new JRadioButton("Others");
		 others.setFont(new Font("Raleway", Font.BOLD,14));
		 others.setBackground(Color.white);
		 others.setBounds(920, 450, 100, 40);
		 add(others);
		 ButtonGroup marriedORunmarriedORothers = new ButtonGroup();
		 marriedORunmarriedORothers.add(married);
		 marriedORunmarriedORothers.add(unmarried);
		 marriedORunmarriedORothers.add(others);
		 
		 
		 
		 JLabel address = new JLabel("Address: ");
		 address.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 address.setBounds(500,500,300,40);
		 add(address);
		  addresstf = new JTextField();
		 addresstf.setFont(new Font("Raleway", Font.BOLD,14));
		 addresstf.setBounds(680, 500, 300, 40);
		 add(addresstf);
		 
		 JLabel city = new JLabel("City: ");
		 city.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 city.setBounds(500,550,300,40);
		 add(city);
		 citytf = new JTextField();
		 citytf.setFont(new Font("Raleway", Font.BOLD,14));
		 citytf.setBounds(680, 550, 300, 40);
		 add(citytf);
		 
		 JLabel state = new JLabel("State: ");
		 state.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 state.setBounds(500,600,300,40);
		 add(state);
		 statetf = new JTextField();
		 statetf.setFont(new Font("Raleway", Font.BOLD,14));
		 statetf.setBounds(680, 600, 300, 40);
		 add(statetf);
		 
		 JLabel pincode = new JLabel("Pincode: ");
		 pincode.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 pincode.setBounds(500,650,300,40);
		 add(pincode);
		 pincodetf = new JTextField();
		 pincodetf.setFont(new Font("Raleway", Font.BOLD,14));
		 pincodetf.setBounds(680, 650, 300, 40);
		 add(pincodetf);
		 
		 next = new JButton("Next");
		 next.setBackground(Color.BLACK);
		 next.setForeground(Color.WHITE);
		 next.setFont(new Font("Raleway" ,  Font.BOLD ,14));
		 next.setBounds(650, 710, 150, 40);
		 next.addActionListener(this);
		 add(next);
		 
	}
public static void main(String args[]) 
	{
			new SignupOne();
	}

public void actionPerformed(ActionEvent e) {
	if(e.getSource()==next) {
		String formno= sendformno;
		String name= nametf.getText();
		String fathersname= fatherstf.getText();
		String dob= ((JTextField) date.getDateEditor().getUiComponent()).getText();
		String gender = null;
		if (male.isSelected()){
			gender="Male";
		}else if(female.isSelected()) {
			gender="Female";
		} 
		String email = emailtf.getText();
		String maritalstatus = null;
		if(married.isSelected()) {
			maritalstatus="Married";
		}else if(unmarried.isSelected()) {
			maritalstatus="Unmaried";
		} else maritalstatus="Others";
		String address = addresstf.getText();
		String city= citytf.getText();
		String state=statetf.getText();
		String pincode = pincodetf.getText();
		
		try {
			if(name.equals("")) {
				JOptionPane.showMessageDialog(null , "Name is required !");
			}else if(fathersname.equals("")) {
				JOptionPane.showMessageDialog(null , "Father's name is required !");
			}else if(dob.equals("")) {
				JOptionPane.showMessageDialog(null , "DOB is required !");
			}else if(email.equals("")) {
				JOptionPane.showMessageDialog(null , "Email is required !");
			}else if(pincode.equals("")) {
				JOptionPane.showMessageDialog(null , "Pincode is required !");
			}else {
				DatabaseConnection c = new DatabaseConnection();
				String sqlquery =" insert into signuptable values('"+formno+"','"+name+"','"+fathersname+"','"+dob+"','"+gender+"','"+email+"','"+maritalstatus+"','"+address+"','"+city+"','"+state+"','"+pincode+"');";
				c.s.executeUpdate(sqlquery);
				SignupTwo signupTwo = new SignupTwo(formno);
				setVisible(false);
			}
		} catch (Exception e2) {
			System.out.println(e2);
		}
		
	}
}
}
