import java.awt.event.ActionEvent;
import java.awt.event.*;
import java.util.Iterator;
import java.util.Random;
import com.toedter.calendar.JDateChooser;
import javax.swing.*; 												//1. Import swing to use Frames
import java.awt.*;

public class SignupTwo extends JFrame implements ActionListener {

	JTextField pantf,aadhartf;
	JComboBox<?> religiontf,categorytf,incometf,edutf,occupationtf ;  
	JButton next;
	JRadioButton senioryes,seniorno,existyes,existno;
	public static String formno,pin="";
	
	SignupTwo(String form_number){
		 
		SignupTwo.formno = form_number; 
		setVisible(true); 
		 getContentPane().setBackground(Color.WHITE);
		 setSize(1600,900);	//defines size of frame
		 setLocation(0,0); //set location of window with reference to the top left corner as origin
		 setLayout(null); 
		 setTitle("SIGN UP Page 2"); //set title of window
		 
		 
		 JLabel additionaldetails = new JLabel("Page 2: Additional Details " );
		 additionaldetails.setFont(new Font("Raleway",Font.BOLD, 30));
		 additionaldetails.setBounds(500,40,600,40);
		 add(additionaldetails);
		 JLabel form = new JLabel("Form No. "+ formno );
		 form.setFont(new Font("Raleway",Font.BOLD, 16));
		 form.setBounds(625,120,600,40);
		 add(form);
		
		 JLabel religionname = new JLabel("Religion: ");
		 religionname.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 religionname.setBounds(500,200,150,40);
		 add(religionname);
		 String valReligion[]= {"Hindu","Muslim","Sikh","Christian","Others"};
		 religiontf = new JComboBox<Object>(valReligion);
//		 religiontf.setFont(new Font("Raleway", Font.BOLD,14));
		 religiontf.setBackground(Color.WHITE);
		 religiontf.setBounds(680, 200, 300, 40);
		 add(religiontf);
		 
		 
		 JLabel categoryname = new JLabel("Category: ");
		 categoryname.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 categoryname.setBounds(500,250,300,40);
		 add(categoryname);
		 String valCategory[] = {"General", "OBC","SC","ST","NT"}; 
		 categorytf = new JComboBox<Object>(valCategory);
//		 categorytf.setFont(new Font("Raleway", Font.BOLD,14));
		 categorytf.setBounds(680, 250, 300, 40);
		 add(categorytf);
		 
		 JLabel incomeclass = new JLabel("Income: ");
		 incomeclass.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 incomeclass.setBounds(500,300,300,40);
		 add(incomeclass);
		 String valIncome[]= {"Under 5L","5-10L","10L-20L","20L-50L","Above 50L"};
		 incometf= new JComboBox<Object>(valIncome);
		 incometf.setBounds(680, 300, 300, 40);
		 incometf.setBackground(Color.WHITE);
		 add(incometf);

		 JLabel education = new JLabel("Ed. Qualification: ");
		 education.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 education.setBounds(500,350,300,40);
		 add(education);
		 String edulist[]= {"High School","Under Graduate","Master's","PHD"};
		 edutf= new JComboBox<Object>(edulist);
		 edutf.setBounds(680, 350, 300, 40);
		 edutf.setBackground(Color.WHITE);
		 add(edutf);
		 
		 JLabel occupation = new JLabel("Occupation: ");
		 occupation.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 occupation.setBounds(500,400,300,40);
		 add(occupation);
		 String valoccupationtf[]= {"Student","Engineer","Lecturer","Scientist","Banking", "CA","Business"};
		 occupationtf= new JComboBox<Object>(valoccupationtf);
		 occupationtf.setBounds(680, 400, 300, 40);
		 occupationtf.setBackground(Color.WHITE);
		 add(occupationtf);
		 
		 JLabel pannumber = new JLabel("PAN Number: ");
		 pannumber.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 pannumber.setBounds(500,450,300,40);
		 add(pannumber);
		 pantf = new JTextField();
//		 pantf.setFont(new Font("Raleway", Font.BOLD,14));
		 pantf.setBounds(680, 450, 300, 40);
		 add(pantf);
		 
		 JLabel aadharnumber = new JLabel("Aadhar Number: ");
		 aadharnumber.setFont(new Font("Raleway",Font.ROMAN_BASELINE, 24));
		 aadharnumber.setBounds(500,500,300,40);
		 add(aadharnumber);
		 aadhartf = new JTextField();
//		 aadhartf.setFont(new Font("Raleway", Font.BOLD,14));
		 aadhartf.setBounds(680, 500, 300, 40);
		 add(aadhartf);
		 
		 JLabel seniorcitizen = new JLabel("Senior Citizen:");
		 seniorcitizen.setFont(new Font("Raleway", Font.ROMAN_BASELINE,24));
		 seniorcitizen.setBounds(500,550,300,40);
		 add(seniorcitizen);
		 senioryes = new JRadioButton("Yes");
		 senioryes.setBounds(680, 550, 100, 40);
//		 senioryes.setFont(new Font("Raleway", Font.BOLD,14));
		 senioryes.setBackground(Color.white);
		 add(senioryes);
		 seniorno = new JRadioButton("No");
//		 seniorno.setFont(new Font("Raleway", Font.BOLD,14));
		 seniorno.setBackground(Color.white);
		 seniorno.setBounds(800, 550, 100, 40);
		 add(seniorno);
		 ButtonGroup senioryesORseniorno= new ButtonGroup();
		 senioryesORseniorno.add(senioryes);
		 senioryesORseniorno.add(seniorno);
		 
		 JLabel exisitingaccount = new JLabel("Existing Account:");
		 exisitingaccount.setFont(new Font("Raleway", Font.ROMAN_BASELINE,24));
		 exisitingaccount.setBounds(500,600,300,40);
		 add(exisitingaccount);
		 existyes = new JRadioButton("Yes");
		 existyes.setBounds(680, 600, 100, 40);
//		 existyes.setFont(new Font("Raleway", Font.BOLD,14));
		 existyes.setBackground(Color.white);
		 add(existyes);		 
		 existno = new JRadioButton("No");
		 existno.setFont(new Font("Raleway", Font.BOLD,14));
		 existno.setBackground(Color.white);
		 existno.setBounds(800, 600, 100, 40);
		 add(existno);
		 ButtonGroup existyesORexistno = new ButtonGroup();
		 existyesORexistno.add(existyes);
		 existyesORexistno.add(existno);
		 
		 next = new JButton("Next");
		 next.setBackground(Color.BLACK);
		 next.setForeground(Color.WHITE);
		 next.setFont(new Font("Raleway" ,  Font.BOLD ,14));
		 next.setBounds(650, 700, 150, 40);
		 next.addActionListener(this);
		 add(next);
		 
	}
public static void main(String args[]) 
	{
		SignupTwo obj = new SignupTwo(formno);
	}

public void actionPerformed(ActionEvent e) {
	if(e.getSource()==next) {
		
		String religion = religiontf.getSelectedItem().toString();
		String category= categorytf.getSelectedItem().toString();
		String income= incometf.getSelectedItem().toString();
		String edu= edutf.getSelectedItem().toString();
		String occupation =occupationtf.getSelectedItem().toString();
		String PAN = pantf.getText();
		String Aadhaar = aadhartf.getText();
		String seniority = null;
		if (senioryes.isSelected()){
			seniority="Senior Citizen";
		}else if(seniorno.isSelected()) {
			seniority="Non Senior Citizen";
		} 
		String existinguser = null;
		if (existyes.isSelected()){
			existinguser="Existing";
		}else if(existno.isSelected()) {
			existinguser="Non Existing";
		} 		
		try {
			if(religion.equals("")) {
				JOptionPane.showMessageDialog(null , "Religion is required !");
			}else if(category.equals("")) {
				JOptionPane.showMessageDialog(null , "Category is required !");
			}else if(edu.equals("")) {
				JOptionPane.showMessageDialog(null , "Educational qualification is required !");
			}else if(PAN.equals("")) {
				JOptionPane.showMessageDialog(null , "PAN is required !");
			}else if(Aadhaar.equals("")) {
				JOptionPane.showMessageDialog(null , "Aadhar number is required !");
			}else {
				DatabaseConnection c = new DatabaseConnection();
				String sqlquery =" insert into signupadditionaltable values('"+formno+"','"+pin+"','"+religion+"','"+category+"','"+income+"','"+edu+"','"+occupation+"','"+PAN+"','"+Aadhaar+"','"+seniority+"','"+existinguser+"');";
				c.s.executeUpdate(sqlquery);
				setVisible(false);
				new SignupTHREE(formno);
			}	
		} catch (Exception e2) {
			System.out.println(e2);
		}
		
	}
}
}
