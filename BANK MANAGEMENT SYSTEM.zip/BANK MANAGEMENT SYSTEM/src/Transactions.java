
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.* ;

public class Transactions extends JFrame implements ActionListener{
	
	   JLabel l1;
	    JButton b1,b2,b3,b4,b5,b6,b7;
	    static String pin;
	    static String formno;
	    
	Transactions(String formno,String pin){
		setTitle("WELCOME"); //set title of window
		setLayout(null); 
		Transactions.pin = pin;
		Transactions.formno=formno;
		 setSize(1600,900);	//defines size of frame
		 getContentPane().setBackground(Color.WHITE);
		 setLocation(0,0); //set location of window with reference to the top left corner as origin
		 
		 	String imagePath = "icons/atm.jpg";
		 	ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource(imagePath));
		 	Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
	        ImageIcon i3 = new ImageIcon(i2);
	        JLabel l2 = new JLabel(i3);
	        l2.setBounds(0, 0, 960, 1080);
	        add(l2);
	        
	        l1 = new JLabel("Please Select Your Transaction");
	        l1.setForeground(Color.WHITE);
	        l1.setFont(new Font("System", Font.BOLD, 16));
	        
	       
	        b1 = new JButton("DEPOSIT");
	        b2 = new JButton("CASH WITHDRAWL");
	        b3 = new JButton("FAST CASH");
	        b5 = new JButton("PIN CHANGE");
	        b7 = new JButton("EXIT");
	        
	        setLayout(null);
	        
	        l1.setBounds(235,400,700,35);
	        l2.add(l1);
	        
	        b1.setBounds(170,499,150,35);
	        l2.add(b1);
	        
	        b2.setBounds(390,499,150,35);
	        l2.add(b2);
	        
	        b3.setBounds(170,543,150,35);
	        l2.add(b3);
	        
	     
	        b5.setBounds(170,588,150,35);
	        l2.add(b5);
	        

	        
	        b7.setBounds(390,633,150,35);
	        l2.add(b7);
	        
	        
	        b1.addActionListener(this);
	        b2.addActionListener(this);
	        b3.addActionListener(this);
	        b5.addActionListener(this);
	        b7.addActionListener(this);
	        
	        setSize(960,1080);
	        setLocation(500,0);
	        setUndecorated(true);
	       
	        setVisible(true); 		//makes the frame visible to user, it is FALSE by default
	        
	}

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b1){ 
            setVisible(false);
            new Deposit(formno,pin).setVisible(true);
        }else if(ae.getSource()==b2){ 
            setVisible(false);
            new CashWithdrawl(formno,pin).setVisible(true);
        }else if(ae.getSource()==b3){ 
            setVisible(false);
            new FastCash(formno,pin).setVisible(true);
        }else if(ae.getSource()==b5){ 
            setVisible(false);
            new ChangePin(formno,pin).setVisible(true);
        }else if(ae.getSource()==b7){ 
        	setVisible(false);
            System.exit(0);
        }
    }
	public static void main(String[] args) {
		new Transactions(formno,pin).setVisible(true);
	}
}
